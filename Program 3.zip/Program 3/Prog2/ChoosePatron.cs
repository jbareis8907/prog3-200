﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class ChoosePatronForm : Form
    {
        List<LibraryPatron> libList = new List<LibraryPatron>();

        public ChoosePatronForm(List<LibraryPatron> _libList)
        {
            libList = _libList;

            InitializeComponent();
        }

        private void choosePatronOkButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void ChoosePatronForm_Load(object sender, EventArgs e)
        {
            foreach (var p in libList)
            {
                choosePatronComboBox.Items.Add(p);
            }
        }
    }
}
