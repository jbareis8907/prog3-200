﻿namespace LibraryItems
{
    partial class ChoosePatronForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.choosePatronLabel = new System.Windows.Forms.Label();
            this.choosePatronComboBox = new System.Windows.Forms.ComboBox();
            this.choosePatronOkButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // choosePatronLabel
            // 
            this.choosePatronLabel.AutoSize = true;
            this.choosePatronLabel.Location = new System.Drawing.Point(12, 51);
            this.choosePatronLabel.Name = "choosePatronLabel";
            this.choosePatronLabel.Size = new System.Drawing.Size(109, 20);
            this.choosePatronLabel.TabIndex = 0;
            this.choosePatronLabel.Text = "Select Patron:";
            // 
            // choosePatronComboBox
            // 
            this.choosePatronComboBox.FormattingEnabled = true;
            this.choosePatronComboBox.Location = new System.Drawing.Point(127, 48);
            this.choosePatronComboBox.Name = "choosePatronComboBox";
            this.choosePatronComboBox.Size = new System.Drawing.Size(190, 28);
            this.choosePatronComboBox.TabIndex = 1;
            // 
            // choosePatronOkButton
            // 
            this.choosePatronOkButton.Location = new System.Drawing.Point(116, 112);
            this.choosePatronOkButton.Name = "choosePatronOkButton";
            this.choosePatronOkButton.Size = new System.Drawing.Size(105, 36);
            this.choosePatronOkButton.TabIndex = 2;
            this.choosePatronOkButton.Text = "OK";
            this.choosePatronOkButton.UseVisualStyleBackColor = true;
            this.choosePatronOkButton.Click += new System.EventHandler(this.choosePatronOkButton_Click);
            // 
            // ChoosePatronForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 172);
            this.Controls.Add(this.choosePatronOkButton);
            this.Controls.Add(this.choosePatronComboBox);
            this.Controls.Add(this.choosePatronLabel);
            this.Name = "ChoosePatronForm";
            this.Text = "Choose Patron";
            this.Load += new System.EventHandler(this.ChoosePatronForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label choosePatronLabel;
        private System.Windows.Forms.ComboBox choosePatronComboBox;
        private System.Windows.Forms.Button choosePatronOkButton;
    }
}